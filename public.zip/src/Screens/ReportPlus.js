import React from 'react'

export default function ReportPlus() {
  return (
    <div>ReportPlus</div>
  )
}
