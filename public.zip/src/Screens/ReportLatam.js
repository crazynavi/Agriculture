import React from 'react'

export default function ReportLatam() {
  return (
    <div>ReportLatam</div>
  )
}
