import React from 'react'

export default function ReportClimate() {
  return (
    <div>ReportClimate</div>
  )
}
