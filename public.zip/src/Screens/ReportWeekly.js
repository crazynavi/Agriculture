import React from 'react'

export default function ReportWeekly() {
  return (
    <div>ReportWeekly</div>
  )
}
